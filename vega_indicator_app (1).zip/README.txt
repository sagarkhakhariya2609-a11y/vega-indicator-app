# Vega Indicator App

This is a simple Streamlit app to analyze option chain Vega values.
Upload a CSV file with columns: Strike, Type, Vega.
The app will classify Vega as Positive or Negative.
